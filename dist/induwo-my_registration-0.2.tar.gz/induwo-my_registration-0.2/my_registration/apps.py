from django.apps import AppConfig


class InduwoRegistrationConfig(AppConfig):
    name = 'my_registration'
